export declare const oids: {
    "0.2.262.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.0.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.5.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.5.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.2.5.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.3.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.1.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.2.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.3.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.35": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.36": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.37": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.38": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.39": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.51": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.7.52": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.11.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.12.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.12.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.12.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.12.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.12.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.12.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.2.262.1.10.12.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.2.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.2.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.4.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.4.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.4.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.4.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.4.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.1.4.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.5.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.1.5.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.2.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.2.2.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.127.0.7.3.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.1862": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.1862.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.1862.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.1862.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.1862.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.4.0.1862.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.9.2342.19200300.100.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.9.2342.19200300.100.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "0.9.2342.19200300.100.1.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.0.10118.3.0.49": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.0.10118.3.0.50": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.0.10118.3.0.55": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.2.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.1.4.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.1.1.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.2.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.2.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.2.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.4.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.4.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.3.1.3.2.4.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.1.333.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.68980861.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.68980861.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.68980861.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.68980861.1.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.68980861.1.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.68980861.1.1.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.36.75878867.1.100.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.392.200011.61.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.392.200011.61.1.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.1.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.5.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.7.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.7.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.10.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.10.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.10.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.10.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200004.10.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.35": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.36": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.37": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.38": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.39": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.43": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.44": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.410.200046.1.1.45": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.31.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.31.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.31.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.31.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.31.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.31.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.31.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.31.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.30.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.30.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.35.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.35.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.35.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.35.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.36.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.36.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.14.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.14.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.13.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.13.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.643.2.2.96": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.752.34.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.752.34.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.752.34.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.752.34.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.752.34.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.752.34.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10040.4.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.1.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.1.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.1.2.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.1.2.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.0.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.3.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.4.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.4.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.4.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.4.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10045.4.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10046.3.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10065.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10065.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.10065.2.3.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.65": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.65.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.66": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.66.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.66.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.66.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.66.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.66.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.67": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.67.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.68": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.68.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113533.7.68.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.5.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.7.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.15.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.15.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.15.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.15.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.15.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.15.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.0.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.1.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.35": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.36": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.37": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.38": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.39": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.43": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.44": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.45": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.46": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.47": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.48": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.49": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.50": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.2.51": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.3.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.6.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.6.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.6.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.6.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.6.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.8.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.9.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.9.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.9.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.9.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.16.11.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.22.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.22.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.23.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.25.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.25.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.25.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.25.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.25.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.9.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.5.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.10.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.10.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.10.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.10.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.10.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.12.10.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.15.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.15.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.15.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.1.15.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.2.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113549.3.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.114021.1.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.114021.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.2.241": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.3.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.3.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.3.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.3.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.3.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.3.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.3.46": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.2.281": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.145": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1327": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1328": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1329": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1330": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1331": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1332": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1333": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1334": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1335": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1429": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1430": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1431": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1432": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1433": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1434": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1435": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1436": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1437": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1438": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1439": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1674": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.1.4.1675": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.4.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.4.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113556.4.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113628.114.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.1.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.2.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.2.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.5.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.5.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.6.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.6.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.4.6.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.5.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.6.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.6.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.840.113635.100.6.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.2.1.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.3.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.3.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.6.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.8.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.9.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.11.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.11.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.11.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.11.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.10.12.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.13.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.13.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.13.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.13.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.16.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.17.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.17.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.17.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.20.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.20.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.20.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.20.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.20.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.20.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.21.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.25.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.31.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.47.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.47.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.60.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.61.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.60.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.60.2.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.60.2.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.311.88.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.188.7.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.188.7.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.188.7.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.188.7.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.188.7.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.2428.10.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.2712.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.2786.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.1.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.1.2.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.3.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.3.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.3.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.3.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.4.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.4.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.4.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.4.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.4.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.4.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.42.11172.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.54.11940.54": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3029.88.89.90.90.89": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3401.8.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3576.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3576.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3576.7.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3576.7.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3576.7.65": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3576.7.97": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3576.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.3576.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.50": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.60": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.70": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.80": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.81": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.90": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.95": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5309.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5309.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5309.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5309.1.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5309.1.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5472": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5472.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5472.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5472.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5472.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5770.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.5770.0.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.6449.1.2.1.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.6449.1.2.2.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.6449.1.3.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.6449.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.8301.3.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.8301.3.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.8231.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.12.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.43": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.11591.13.2.44": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.16334.509.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.16334.509.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.16334.509.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.16334.509.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.0.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.3.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.4.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.5.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.6.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.6.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.6.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.8.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.8.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.8.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.9.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.9.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.9.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.9.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.9.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.10.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.10.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.10.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.10.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.10.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.11.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.14.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.20.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.20.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.7.48.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.8.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.8.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.8.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.5.5.8.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.12.2.1011.7.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.2.26.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.2.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.3.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.7.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.7.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.14.7.2.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.1.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.3.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.3.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.3.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.3.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.4.512.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.1.5.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.1.1.1024.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.1.2.1024.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.3.2.8.1.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.4.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.4.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.3.4.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.6.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.6.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.7.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.7.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.7.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.11.1.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.3.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.4.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.5.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.5.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.5.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.5.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.5.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.5.1.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.6.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.35": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.36": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.37": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.38": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.39": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.43": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.36.8.7.1.45": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.101.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.101.1.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.35": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.36": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.37": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.38": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.132.0.39": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.8.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.9.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.11.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.16.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.17.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.18.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.19.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.20.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.21.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.22.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.23.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.25.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.35": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.36": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.37": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.38": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.39": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.43": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.44": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.45": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.46": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.47": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.48": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.49": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.50": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.51": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.52": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.53": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.54": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.55": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.56": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.57": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.58": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.59": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.60": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.61": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.62": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.63": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.64": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.65": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.66": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.67": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.68": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.69": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.70": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.71": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.72": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.73": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.74": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.75": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.76": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.4.82": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.6.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.8.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.32.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.35": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.36": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.37": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.37.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.38": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.39": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.43": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.44": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.45": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.46": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.47": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.48": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.49": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.50": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.51": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.52": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.53": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.54": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.55": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.56": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.57": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.58": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.59": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.60": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.61": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.62": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.63": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.64": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.65": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.66": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.67": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.68": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.5.29.69": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.724.1.2.2.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.1.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.48": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.49": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.50": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.66": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.72": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.73": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.74": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.75": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.2.76": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.10.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.11.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.11.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.11.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.11.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.11.3.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.13.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.13.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.13.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.13.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.3.13.0.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.43": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.44": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.45": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.46": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.47": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.48": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.49": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.50": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.51": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.52": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.53": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.54": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.55": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.56": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.57": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.58": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.59": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.5.60": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.7.1.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.8.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.8.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.10.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.10.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.10.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.11.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.11.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.11.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.11.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.11.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.11.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.1.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.1.0.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.1.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.1.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.2.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.2.0.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.2.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.2.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.3.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.3.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.3.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.0.3.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.2.1.12.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.48.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.48.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.48.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.48.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.48.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.1.48.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.41": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.42": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.43": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.44": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.45": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.46": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.47": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.1.48": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.101.3.4.3.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.40": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.50": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.51": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.52": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.69": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.82": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.92": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.95": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.130": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.131": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.132": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.2.8.133": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.9.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.9.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113719.1.9.4.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.1.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.2.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.3.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.3.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.3.1.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.3.1.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.3.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113730.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.6.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.6.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.6.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.6.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.6.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.7.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.7.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.7.1.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.7.23.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.8.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.9.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.9.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.9.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.9.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.9.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.9.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.9.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114412.1.3.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114412.1.3.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114412.1.3.0.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114412.1.3.0.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.0.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.0.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.2.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.3.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.3.0.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.3.0.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.5.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.7.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.7.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.7.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.7.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.7.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.7.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.7.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.8.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.8.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.8.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.8.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.8.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.8.6011": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.0": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.8": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.9": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.11": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.12": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.13": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.14": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.15": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.16": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.17": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.18": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.19": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.20": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.21": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.22": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.23": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.24": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.25": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.26": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.27": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.28": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.29": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.30": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.31": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.32": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.33": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.34": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.35": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.36": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.37": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.9.38": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.10": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.42.10.392": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.23.136.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.54.1775.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.54.1775.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.54.1775.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.54.1775.5": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.54.1775.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.54.1775.7": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.54.1775.99": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.6449.1.2.1.5.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.34697.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.34697.2.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.34697.2.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.34697.2.4": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.578.1.26.1.3.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.22234.2.5.2.3.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.6334.1.100.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114412.2.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.528.1.1001.1.1.1.12.6.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114028.10.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.14370.1.6": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.4146.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114413.1.7.23.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.14777.6.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.14777.6.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.782.1.2.1.8.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.8024.0.2.100.1.2": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.2.392.200091.100.721.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114404.1.1.2.4.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "1.3.6.1.4.1.23223.1.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114414.1.7.23.3": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.756.1.89.1.2.1.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.113733.1.7.48.1": {
        d: string;
        c: string;
        w: boolean;
    };
    "2.16.840.1.114171.500.9": {
        d: string;
        c: string;
        w: boolean;
    };
    END: string;
};
